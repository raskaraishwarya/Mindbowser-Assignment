from django.db import models
from django.contrib.auth.models import User

#CASCADE : Basically means that whenever a user is deleted we'll go ahead and delete that relationship to that UserRegister.
#OneToOneField : User can have one UserRegister and UserRegister can only have one user.

class UserRegister(models.Model):
     user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)   #27 Code with harry
     name = models.CharField(max_length = 30)
     username = models.CharField(max_length = 30)
     password = models.CharField(max_length = 30)
     confirm_password = models.CharField(max_length = 30)
     address = models.CharField(max_length = 30)
     contact = models.CharField(max_length = 40)
     resume = models.FileField(upload_to='files')

     def __str__(self):
         return str(self.name)

     # def __str__(self):
     #     return self.name

from django import forms
from userapp.models import UserRegister


class UserRegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    confirm_password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = UserRegister
        fields = ['name', 'username', 'password',
                  'confirm_password', 'address', 'contact', 'resume']
        #fields ="__all__"

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserRegister
        fields = "__all__"
        exclude = ['user','password' , 'confirm_password']

from django.urls import path
from userapp import views
urlpatterns=[
    path('userwelcome/',views.welcome_user), #User Welcome

    path('register/',views.user_register),  #User register
    path('login/',views.user_login),  #User login
    path('userdashboard/',views.user_dashboard), #User dashboard

    path('userprofile/', views.user_profile), #User Profile

    path('itjoblist/',views.it_job_list),     #IT job list

    path('mechjoblist/',views.mech_job_list),   #Mech job list

    path('civiljoblist/',views.civil_job_list),  #Civil job list

    path('itjobapply/<int:id>/',views.it_job_apply), #IT job Apply

    path('mechjobapply/<int:id>/',views.mech_job_apply), #Mech job apply

    path('civiljobapply/<int:id>/',views.civil_job_apply) #Civil job apply
]

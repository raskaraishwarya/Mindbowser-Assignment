from django.shortcuts import render,redirect

from userapp.models import UserRegister
from userapp.forms import UserRegisterForm,UserProfileForm

from django.contrib.auth.models import User

from django.contrib import messages

#IT,MECHANICAL,CIVIL JOBS
from firstapp.forms import ITJobInfoForm,MECHJobInfoForm,CivilJobInfoForm
from firstapp.models import ITJobInfo,MechJobInfo,CivilJobInfo

#Extra code added
from django.contrib.auth.decorators import login_required
from .decorators import user_login_required
from django.contrib.sessions.models import Session

#User welcome page
def welcome_user(request):
    return render(request,"user/welcome_user.html")

#User registration
def user_register(request):
    form = UserRegisterForm()
    if request.method == "POST":
        form = UserRegisterForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect("/userapp/login/")
    return render(request,"user/user_register.html",{"form" : form})

#User login
def user_login(request):
    if (request.method == "POST"):
        username = request.POST.get("uname")
        password = request.POST.get("upass")
        #print(username,password)
        try:
            user = UserRegister.objects.get(username = username ,password = password)
            print(user)
            if user is not None:
                #Session start
                request.session['user'] = user.username # Use for decorators
                request.session['user_id'] = user.id  # Use for fetch user id
                print("Session set id:",request.session['user'])
                return redirect("/userapp/userdashboard/")
            else:
                messages.error(request,"Please enter valid username and password")
                return redirect("/userapp/login/")
        except:
            #print("Their is error")
            messages.error(request,"Please enter valid username and password")
            return redirect("/userapp/login/")
    return render(request,"user/user_login.html")

#User dashboard
@user_login_required
def user_dashboard(request,*args,**kwargs):
    return render(request,"user/user_dashboard.html")

#Show IT Record
@user_login_required
def it_job_list(request):
    obj = ITJobInfo.objects.all()
    return render(request,"ITUserApp/it_show.html",{"obj" : obj })

#Show MECH Record
@user_login_required
def mech_job_list(request):
    obj = MechJobInfo.objects.all()
    return render(request,"MechUserApp/mech_show.html",{"obj" : obj })

#Show MECH Record
@user_login_required
def civil_job_list(request):
    obj = CivilJobInfo.objects.all()
    return render(request,"CivilUserApp/civil_show.html",{"obj" : obj })

#User Profile
@user_login_required
def user_profile(request):
    session_id = request.session.get('user_id')
    obj = UserRegister.objects.get(pk=session_id)
    if request.method == "POST":
        userform = UserProfileForm(request.POST,request.FILES,instance=obj)
        if(userform.is_valid()):
            userform.save()
            return redirect('/userapp/userdashboard/')
    userform = UserProfileForm(instance=obj)
    return render(request,"user/user_profile.html",{'userform': userform})

# IT job apply
@user_login_required
def it_job_apply(request,*args,**kwargs):
    jobid = kwargs.get('id')
    if(jobid):
        messages.success(request,'You are apply successfully,We will inform you by mail !!!!!')
        obj = ITJobInfo.objects.get(pk=jobid)
        user_id = request.session.get('user_id')
        uobj = UserRegister.objects.get(pk=user_id)
        obj.user.add(uobj)
        print(obj.user.all())
        obj.save()
        return redirect('/userapp/itjoblist/')
    return redirect('/userapp/itjoblist/')

#Mech job apply
@user_login_required
def mech_job_apply(request,*args,**kwargs):
    jobid = kwargs.get('id')
    if(jobid):
        messages.success(request,'You are apply successfully,We will inform you by mail !!!!!')
        obj = MechJobInfo.objects.get(pk=jobid)
        user_id = request.session.get('user_id')
        uobj = UserRegister.objects.get(pk=user_id)
        obj.user.add(uobj)
        print(obj.user.all())
        obj.save()
        return redirect('/userapp/mechjoblist/')
    return redirect('/userapp/mechjoblist/')

#Civil job apply
@user_login_required
def civil_job_apply(request,*args,**kwargs):
    jobid = kwargs.get('id')
    if(jobid):
        messages.success(request,'You are apply successfully,We will inform you by mail !!!!!')
        obj = CivilJobInfo.objects.get(pk=jobid)
        user_id = request.session.get('user_id')
        uobj = UserRegister.objects.get(pk=user_id)
        obj.user.add(uobj)
        print(obj.user.all())
        obj.save()
        return redirect('/userapp/civiljoblist/')
    return redirect('/userapp/civiljoblist/')





























































#*******************************************************************************************************
#User profile

# def user_profile(request):
#     if request.method == "POST":
#         form = UserProfileForm(request.POST,instance=request.user)
#         print(request.POST)
#
#         if form.is_valid():
#             form.save()
#             return redirect('/userapp/userdashboard/')
#     else:
#         form = UserProfileForm(instance=request.user)
#         args = {'form':form}
#         return render(request,"user/user_profile.html",args)

# def user_profile(request):
#     obj = UserRegister.objects.get(pk = id)
#     if request.method == 'POST':
#         form = UserProfile(request.POST, request.FILES, instance = obj)
#         if form.is_valid():
#             form.save()
#             return redirect('/userapp/userdashboard/')
#     form = UserProfile(instance = obj)
#     return render(request,"user/user_profile.html",{'form':form})

#User profile
# def user_profile(request):
    # userform = UserProfileForm()
    # return render(request,"user/user_profile.html",{"userform":userform})

    # print(request.POST)
    # data = ""
    # if request.method == "POST":
    #     x = request.POST.get("uname")
    #     print(x)
    #     data = UserProfileForm.objects.filter(name__contains = "uname")
    #     return redirect('/userapp/userdashboard/')
    # return render(request,"user/user_profile.html",{"data":data})

# def user_profile(request):
#     context = {}
#     data = UserRegister.objects.get(user__id=request.user.id)
#     context["data"]=data
#     if request.method == "POST":
#         print(request.POST)
#         x = User.objects.get("uname")
#     return render(request,"user/user_profile.html",context)


#**************************************************************************************************************



# #User IT job apply
# #@user_login_required
# def it_apply(request,*args,**kwargs):
#     jobid =kwargs.get('id')
#     if(jobid):
#         messages.success(request,'You are apply successfully.We will inform you by mail !!!!')
#         obj = ITJobInfo.objects.get(pk=jobid)
#         obj.save()
#         return redirect('/userapp/itjoblist/')
#     return redirect('/userapp/itjoblist/')

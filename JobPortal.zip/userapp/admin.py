from django.contrib import admin

from userapp.models import UserRegister

admin.site.register(UserRegister)

from django.contrib import admin
from django.db import models
from firstapp.models import ITJobInfo,MechJobInfo,CivilJobInfo


#Register ITJobInfo table from model
class ITJobAdmin(admin.ModelAdmin):
    list_display = ['id','company_name','job_title','description','designation','experience','package','position','location']

admin.site.register(ITJobInfo,ITJobAdmin)

#Register MechJobInfo table from model
class MECHJobAdmin(admin.ModelAdmin):
    list_display = ['id','company_name','job_title','description','designation','experience','package','position','location']

admin.site.register(MechJobInfo,MECHJobAdmin)

#Register CivilJobInfo table from model
class CIVILJobAdmin(admin.ModelAdmin):
    list_display = ['id','company_name','job_title','description','designation','experience','package','position','location']

admin.site.register(CivilJobInfo,CIVILJobAdmin)

from django.db import models
from userapp.models import UserRegister
#IT Job table
class ITJobInfo(models.Model):
    company_name = models.CharField(max_length=50)
    job_title = models.CharField(max_length=50)
    description = models.CharField(max_length=500)
    designation = models.CharField(max_length=50)
    experience = models.FloatField(max_length=20)
    package = models.FloatField(max_length=50)
    position = models.PositiveSmallIntegerField()
    location = models.CharField(max_length=30)
    user = models.ManyToManyField(UserRegister)

    def __str__(self):
        return self.company_name

#Mech Job table
class MechJobInfo(models.Model):
    company_name = models.CharField(max_length=50)
    job_title = models.CharField(max_length=50)
    description = models.CharField(max_length=500)
    designation = models.CharField(max_length=50)
    experience = models.FloatField(max_length=20)
    package = models.FloatField(max_length=50)
    position = models.PositiveSmallIntegerField()
    location = models.CharField(max_length=30)
    user = models.ManyToManyField(UserRegister)

    def __str__(self):
        return self.company_name

#Civil Job table
class CivilJobInfo(models.Model):
    company_name = models.CharField(max_length=50)
    job_title = models.CharField(max_length=50)
    description = models.CharField(max_length=500)
    designation = models.CharField(max_length=50)
    experience = models.FloatField(max_length=20)
    package = models.FloatField(max_length=50)
    position = models.PositiveSmallIntegerField()
    location = models.CharField(max_length=30)
    user = models.ManyToManyField(UserRegister)

    def __str__(self):
        return self.company_name

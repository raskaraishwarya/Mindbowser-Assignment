from django.urls import path
from firstapp import views
from django.contrib.auth import views as auth_view

urlpatterns=[
     path('welcome/',views.home ), # Main page

     path('adminwelcome/',views.welcome_admin), #Admin Welcome

     path('adminregister/',views.admin_register), #Admin Registration
     path('adminlogin/',auth_view.LoginView.as_view(template_name = "admin/admin_login.html")), #Admin login
     path('adminlogout/',auth_view.LogoutView.as_view()), #Admin Logout

     path('admindashboard/',views.admin_dashboard), #Admin dashboard IT MECH CIVIl

     #IT JOBS
     path('itshowadmin/',views.it_show_admin), #IT job list
     path('additjob/',views.it_model_form_add),# Add IT job
     path('updateitjob/<int:id>/',views.it_model_form_update),# Update IT job
     path('deleteitjob/<int:id>/',views.it_model_form_delete),# Delete IT job
     path('itviewdata/<int:id>/',views.it_view_data),     #View IT job

     #MECH JOBS
     path('mechshowadmin/',views.mech_show_admin),           #MECH job list
     path('addmechjob/',views.mech_model_form_add),         # Add MECH job
     path('updatemechjob/<int:id>/',views.mech_model_form_update),            # Update MECH job
     path('deletemechjob/<int:id>/',views.mech_model_form_delete),   # Delete MECH job
     path('mechviewdata/<int:id>/',views.mech_view_data),     #View MECH job

     #CIVIL JOBS
     path('civilshowadmin/',views.civil_show_admin),    #CIVIL job list
     path('addciviljob/',views.civil_model_form_add), # Add CIVIL job
     path('updateciviljob/<int:id>/',views.civil_model_form_update),            # Update CIVIL job
     path('deleteciviljob/<int:id>/',views.civil_model_form_delete),   # Delete CIVIL job
     path('civilviewdata/<int:id>/',views.civil_view_data),     #View MECH job

     path('itresume/<int:id>/',views.resume_it),  # Resume IT
     path('mechresume/<int:id>/',views.resume_mech),  # Resume MECH
     path('civilresume/<int:id>/',views.resume_civil)  # Resume CIVIL

]

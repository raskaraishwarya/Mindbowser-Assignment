from django import forms
from django.forms import ModelForm
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from firstapp.models import ITJobInfo,MechJobInfo,CivilJobInfo


#Admin registration
class AdminRegister(UserCreationForm):
    class Meta:
        model = User
        fields = ["username","password1","password2"]

#IT jobs
class ITJobInfoForm(forms.ModelForm):
    class Meta:
        model = ITJobInfo
        fields = "__all__"
        exclude=['user']

#Mechanical jobs
class MECHJobInfoForm(forms.ModelForm):
    class Meta:
        model = MechJobInfo
        fields ="__all__"
        exclude=['user']

#Civil jobs
class CivilJobInfoForm(forms.ModelForm):
    class Meta:
        model = CivilJobInfo
        fields ="__all__"
        exclude=['user']

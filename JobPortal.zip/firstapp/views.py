from django.shortcuts import render,redirect
from firstapp.forms import AdminRegister,ITJobInfoForm,MECHJobInfoForm,CivilJobInfoForm
from firstapp.models import ITJobInfo,MechJobInfo,CivilJobInfo
from django.contrib.auth.decorators import login_required

#Main page job portal
def home(request):
    return render(request,"home.html")

#Admin welcome page
def welcome_admin(request):
    return render(request,"admin/welcome_admin.html")

#Admin registration page
def admin_register(request):
    form = AdminRegister()
    if request.method == "POST":
        form = AdminRegister(request.POST)
        if form.is_valid():
            form.save()
        return redirect("/firstapp/adminlogin/")
    return render(request,"admin/admin_register.html",{"form": form})

#Admin dashboard IT MECH CIVIL job button
@login_required(login_url='/firstapp/adminlogin/')
def admin_dashboard(request):
    return render(request,"admin/admin_dashboard.html")

#******************************************************* IT JOBS START **************************************************#
#Show IT job list
@login_required(login_url='/firstapp/adminlogin/')
def it_show_admin(request):
    data =ITJobInfo.objects.all()
    return render(request,"IT/it_show.html",{"data":data})

#Add IT job form
@login_required(login_url='/firstapp/adminlogin/')
def it_model_form_add(request):
    form = ITJobInfoForm()
    if request.method == "POST":
        form = ITJobInfoForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect("/firstapp/itshowadmin/")
    return render(request,"IT/it_job_add.html",{"form":form})

#Update IT job form
@login_required(login_url='/firstapp/adminlogin/')
def it_model_form_update(request,id):
    obj = ITJobInfo.objects.get(pk = id)
    form = ITJobInfoForm(instance = obj)
    if request.method == "POST":
        form = ITJobInfoForm(request.POST,instance = obj)
        if form.is_valid():
            form.save()
        return redirect("/firstapp/itshowadmin/")
    return render(request,"IT/it_job_update.html",{"form":form,"obj":obj})

#Delete IT job form
@login_required(login_url='/firstapp/adminlogin/')
def it_model_form_delete(request,id):
    obj = ITJobInfo.objects.get(pk = id)
    obj.delete()
    return redirect("/firstapp/itshowadmin/")

#View IT job form
@login_required(login_url='/firstapp/adminlogin/')
def it_view_data(request,id):
    obj = ITJobInfo.objects.get(pk = id)
    return render(request,"IT/it_view.html",{"obj":obj})
#******************************************************* IT JOBS END **************************************************#

#*******************************************************MECH JOBS START***************************************************
#Show IT job list
@login_required(login_url='/firstapp/adminlogin/')
def mech_show_admin(request):
    data = MechJobInfo.objects.all()
    return render(request,"MECH/mech_show.html",{"data":data})

#Add MECH job form
@login_required(login_url='/firstapp/adminlogin/')
def mech_model_form_add(request):
    form = MECHJobInfoForm()
    if request.method == "POST":
        form = MECHJobInfoForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect("/firstapp/mechshowadmin/")
    return render(request,"MECH/mech_job_add.html",{"form":form})

#Update MECH job form
@login_required(login_url='/firstapp/adminlogin/')
def mech_model_form_update(request,id):
    obj = MechJobInfo.objects.get(pk = id)
    form = MECHJobInfoForm(instance = obj)
    if request.method == "POST":
        form = MECHJobInfoForm(request.POST,instance = obj)
        if form.is_valid():
            form.save()
        return redirect("/firstapp/mechshowadmin/")
    return render(request,"MECH/mech_job_update.html",{"form":form,"obj":obj})

#Delete MECH job form
@login_required(login_url='/firstapp/adminlogin/')
def mech_model_form_delete(request,id):
    obj = MechJobInfo.objects.get(pk = id)
    obj.delete()
    return redirect("/firstapp/mechshowadmin/")

#View MECH job form
@login_required(login_url='/firstapp/adminlogin/')
def mech_view_data(request,id):
    obj = MechJobInfo.objects.get(pk = id)
    return render(request,"MECH/mech_view.html",{"obj":obj})
#***********************************************************MECH JOBS END ****************************************************

#**********************************************************CIVIL JOBS*********************************************************
#Show IT job list
@login_required(login_url='/firstapp/adminlogin/')
def civil_show_admin(request):
    data = CivilJobInfo.objects.all()
    return render(request,"CIVIL/civil_show.html",{"data":data})

#Add MECH job form
@login_required(login_url='/firstapp/adminlogin/')
def civil_model_form_add(request):
    form = CivilJobInfoForm()
    if request.method == "POST":
        form = CivilJobInfoForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect("/firstapp/civilshowadmin/")
    return render(request,"CIVIL/civil_job_add.html",{"form":form})

#Update MECH job form
@login_required(login_url='/firstapp/adminlogin/')
def civil_model_form_update(request,id):
    obj = CivilJobInfo.objects.get(pk = id)
    form = CivilJobInfoForm(instance = obj)
    if request.method == "POST":
        form = CivilJobInfoForm(request.POST,instance = obj)
        if form.is_valid():
            form.save()
        return redirect("/firstapp/civilshowadmin/")
    return render(request,"CIVIL/civil_job_update.html",{"form":form,"obj":obj})

#Delete MECH job form
@login_required(login_url='/firstapp/adminlogin/')
def civil_model_form_delete(request,id):
    obj = CivilJobInfo.objects.get(pk = id)
    obj.delete()
    return redirect("/firstapp/civilshowadmin/")

#View CIVIL job form
@login_required(login_url='/firstapp/adminlogin/')
def civil_view_data(request,id):
    obj = CivilJobInfo.objects.get(pk = id)
    return render(request,"CIVIL/civil_view.html",{"obj":obj})
#**********************************************************CIVIL ENDS*********************************************************
#Show IT job applied resume by user
@login_required(login_url='/firstapp/adminlogin/')
def resume_it(request,id):
    itjobs = ITJobInfo.objects.get(pk=id)
    users = itjobs.user.all()
    return render(request,'resume.html',{'user_resume':users})

#Show Mech job applied resume by user
@login_required(login_url='/firstapp/adminlogin/')
def resume_mech(request,id):
    mechjobs = MechJobInfo.objects.get(pk=id)
    users = mechjobs.user.all()
    return render(request,'resume.html',{'user_resume':users})

#Show Civil job applied resume by user
@login_required(login_url='/firstapp/adminlogin/')
def resume_civil(request,id):
    civiljobs = CivilJobInfo.objects.get(pk=id)
    users = civiljobs.user.all()
    return render(request,'resume.html',{'user_resume':users})
